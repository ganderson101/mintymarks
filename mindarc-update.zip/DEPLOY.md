# MindArc — Synology DS420+ Deployment Guide

## Prerequisites

- Synology DS420+ running DSM 7.x
- **Container Manager** installed (DSM Package Center → search "Container Manager")
- SSH enabled on the NAS (Control Panel → Terminal & SNMP → Enable SSH service)
- Git installed on the NAS, or the repo files transferred via File Station
- A domain name added to Cloudflare (for internet access via Cloudflare Tunnel)

---

## One-time setup on the NAS

### 1. SSH into your NAS
```bash
ssh your-username@192.168.x.x
```

### 2. Clone the repo
```bash
git clone https://github.com/ganderson101/mindarc.git /volume1/docker/mindarc
```

### 3. Create a Cloudflare Tunnel

1. Go to [dash.cloudflare.com](https://dash.cloudflare.com) → **Zero Trust** → **Networks** → **Tunnels**
2. Click **Create a tunnel** → choose **Cloudflared** → name it `mindarc`
3. Copy the **token** (the long string after `--token` in the install command shown)
4. Add a **Public Hostname**:
   - Subdomain: `app`
   - Domain: your domain (e.g. `yourdomain.com`)
   - Service type: `HTTP`, URL: `frontend:80`
5. Save the tunnel

### 4. Create your .env file
```bash
cd /volume1/docker/mindarc
cp .env.example .env
nano .env
```

Fill in three values:

```
MINDARC_SECRET=<generate with: openssl rand -hex 32>
ALLOWED_ORIGINS=https://app.yourdomain.com
CLOUDFLARE_TUNNEL_TOKEN=<paste token from step 3>
```

### 4. Build and start
```bash
cd /volume1/docker/mindarc
docker compose -f docker-compose.nas.yml up -d --build
```

The first build takes 3–5 minutes (downloads Node + Python base images, installs deps).

### 5. Verify it's running
```bash
docker compose -f docker-compose.nas.yml ps
# Both services should show status "running (healthy)"
```

Open a browser: `http://<NAS-IP>:3000`

---

## Updating the app

```bash
cd /volume1/docker/mindarc
git pull
docker compose -f docker-compose.nas.yml up -d --build
```

Your data (SQLite in named volume `mindarc_db_data`) survives updates automatically.

---

## Optional: Synology reverse proxy (clean URL on port 80)

To access MindArc at `http://mindarc.local` instead of `http://IP:3000`:

1. DSM → Control Panel → Login Portal → Advanced → **Reverse Proxy**
2. Click **Create**
3. Fill in:
   - **Source**: Protocol `HTTP`, hostname `mindarc.local` (or your NAS hostname), port `80`
   - **Destination**: Protocol `HTTP`, hostname `localhost`, port `3000`
4. In `.env`, set `ALLOWED_ORIGINS=http://mindarc.local`
5. Restart the backend: `docker compose -f docker-compose.nas.yml restart backend`

For HTTPS, first enable a Let's Encrypt certificate in DSM (Control Panel → Security → Certificate), then set source protocol to `HTTPS` in the reverse proxy rule.

---

## PWA install ("Add to Home Screen") requires HTTPS

MindArc is built as a Progressive Web App so the kids can install it on tablets/phones as if it were a native app. **This only works over HTTPS or `localhost`** — it will not work over a plain `http://192.168.x.x` LAN address.

Browsers block service workers on plain HTTP for security reasons, so the "Add to Home Screen" prompt will never appear without HTTPS.

**How to enable it on the NAS:**

1. Get a TLS certificate. Two options:
   - **Let's Encrypt via DSM** (easiest, requires a domain name reachable from the internet):
     DSM → Control Panel → Security → Certificate → Add → *Get a certificate from Let's Encrypt*
   - **Self-signed cert via DSM** (no domain neede